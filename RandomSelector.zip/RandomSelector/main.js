window.onload = function(){
    //document.write("Hello JavaScript");
}

/*$(function(){
    $("input").on("click",function(){
        //alert("Hi");//按鈕按了跳出視窗
        //$("h1").text("Hello");//按鈕按了可以改變那個問號
    });
});
*/
$(function(){
    $("input").on("click",function(){
        var numberOfListItem = $("li").length;
        var randomChildNumber = Math.floor(Math.random()*numberOfListItem);
        $("h1").text($("li").eq(randomChildNumber).text());
        x=document.getElementById("photo").src=(randomChildNumber+1)+".jpg";
    });
});